#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int *data = (int *)malloc(argc * sizeof(int));
    
    if (data == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    printf("\nArgc: %d\n", argc);
    for (int i = 0; i < argc; i++) {
        data[i] = atoi(argv[i]);
    }

    printf("\nPrinting Elements in Reverse:\n");
    for (int i = argc - 1; i > 0; i--) {
        printf("%d ", data[i]);
    }
    
    printf("\n\nEXCEV task Completed\n");

    free(data);
    return 0;
}

